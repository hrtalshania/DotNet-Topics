# GSAP Animation Catalog

## 🟢 ENTRANCE ANIMATIONS

### 1. Fade In
```js
gsap.from(".el", { opacity: 0, duration: 0.8, ease: "power2.out" })
```

### 2. Slide Up Fade
```js
gsap.from(".el", { opacity: 0, y: 60, duration: 0.9, ease: "power3.out" })
```

### 3. Slide In From Left
```js
gsap.from(".el", { opacity: 0, x: -100, duration: 0.8, ease: "power2.out" })
```

### 4. Scale Pop
```js
gsap.from(".el", { opacity: 0, scale: 0.5, duration: 0.6, ease: "back.out(2)" })
```

### 5. Elastic Pop
```js
gsap.from(".el", { opacity: 0, scale: 0, duration: 1.2, ease: "elastic.out(1, 0.5)" })
```

### 6. Stagger Cards
```js
gsap.from(".card", { opacity: 0, y: 40, duration: 0.6, stagger: 0.12, ease: "power3.out" })
```

### 7. Clip Reveal (Curtain)
```js
gsap.from(".el", { clipPath: "inset(0 100% 0 0)", duration: 1.2, ease: "expo.inOut" })
```

### 8. Blur In
```js
gsap.from(".el", { opacity: 0, filter: "blur(20px)", duration: 1, ease: "power2.out" })
```

### 9. Rotate In
```js
gsap.from(".el", { opacity: 0, rotation: -15, transformOrigin: "left center", duration: 0.8 })
```

### 10. Letter Drop (SplitText)
```js
const split = new SplitText(".headline", { type: "chars" })
gsap.from(split.chars, { opacity: 0, y: -50, stagger: 0.04, duration: 0.6, ease: "power3.out" })
```

---

## 🔵 SCROLL ANIMATIONS

### 11. Scroll Fade In
```js
gsap.from(".el", {
  opacity: 0, y: 50,
  scrollTrigger: { trigger: ".el", start: "top 85%", toggleActions: "play none none reverse" }
})
```

### 12. Parallax Background
```js
gsap.to(".bg-layer", {
  yPercent: -40,
  scrollTrigger: { trigger: "body", start: "top top", end: "bottom bottom", scrub: true }
})
```

### 13. Pinned Hero
```js
gsap.timeline({
  scrollTrigger: { trigger: ".hero", pin: true, start: "top top", end: "+=600", scrub: 1 }
}).to(".hero-title", { scale: 0.4, opacity: 0 }).to(".hero-bg", { scale: 1.3 }, 0)
```

### 14. Horizontal Scroll
```js
const sections = gsap.utils.toArray(".panel")
gsap.to(sections, {
  xPercent: -100 * (sections.length - 1),
  ease: "none",
  scrollTrigger: { trigger: ".container", pin: true, scrub: 1, snap: 1 / (sections.length - 1) }
})
```

### 15. Scroll Progress Bar
```js
gsap.to(".progress-bar", {
  scaleX: 1,
  scrollTrigger: { trigger: "body", start: "top top", end: "bottom bottom", scrub: true }
})
```

### 16. Counter Roll on Scroll
```js
const obj = { val: 0 }
gsap.to(obj, {
  val: 9999, duration: 2, ease: "power2.out",
  onUpdate: () => el.textContent = Math.round(obj.val).toLocaleString(),
  scrollTrigger: { trigger: ".counter", start: "top 80%" }
})
```

### 17. SVG Path Draw on Scroll
```js
gsap.from(".path", {
  drawSVG: "0%", duration: 2, ease: "power2.inOut",
  scrollTrigger: { trigger: ".svg-wrap", start: "top 70%" }
})
```

### 18. Stagger on Scroll
```js
gsap.from(".item", {
  opacity: 0, y: 30, stagger: 0.1,
  scrollTrigger: { trigger: ".list", start: "top 75%" }
})
```

---

## 🟡 HOVER & INTERACTIVE

### 19. Magnetic Button
```js
btn.addEventListener("mousemove", (e) => {
  const rect = btn.getBoundingClientRect()
  gsap.to(btn, {
    x: (e.clientX - rect.left - rect.width/2) * 0.4,
    y: (e.clientY - rect.top - rect.height/2) * 0.4,
    ease: "power2.out", duration: 0.3
  })
})
btn.addEventListener("mouseleave", () => gsap.to(btn, { x: 0, y: 0, duration: 0.5, ease: "elastic.out(1,0.5)" }))
```

### 20. 3D Card Tilt
```js
card.addEventListener("mousemove", (e) => {
  const rect = card.getBoundingClientRect()
  const x = (e.clientY - rect.top - rect.height/2) / 10
  const y = -(e.clientX - rect.left - rect.width/2) / 10
  gsap.to(card, { rotationX: x, rotationY: y, transformPerspective: 800, ease: "power1.out", duration: 0.3 })
})
card.addEventListener("mouseleave", () => gsap.to(card, { rotationX: 0, rotationY: 0, duration: 0.5, ease: "back.out" }))
```

### 21. Hover Text Scramble
```js
el.addEventListener("mouseenter", () => {
  gsap.to(el, { duration: 1, scrambleText: { text: el.dataset.text, chars: "upperCase" } })
})
```

### 22. Elastic Drag
```js
Draggable.create(".el", {
  type: "x,y", edgeResistance: 0.65,
  onDragEnd() { gsap.to(this.target, { x: 0, y: 0, ease: "elastic.out(1,0.4)", duration: 1 }) }
})
```

### 23. Click Ripple
```js
document.addEventListener("click", (e) => {
  const ripple = document.createElement("div")
  ripple.className = "ripple"
  document.body.appendChild(ripple)
  gsap.fromTo(ripple,
    { x: e.clientX, y: e.clientY, scale: 0, opacity: 0.6 },
    { scale: 3, opacity: 0, duration: 0.8, ease: "power2.out", onComplete: () => ripple.remove() }
  )
})
```

---

## 🔴 TEXT EFFECTS

### 24. Typewriter
```js
gsap.registerPlugin(TextPlugin)
gsap.to(".el", { duration: 3, text: "Hello World!", ease: "none" })
```

### 25. Character Wave
```js
const split = new SplitText(".text", { type: "chars" })
gsap.to(split.chars, { y: -20, stagger: 0.05, repeat: -1, yoyo: true, ease: "sine.inOut", duration: 0.4 })
```

### 26. Word Reveal (Mask)
```js
const split = new SplitText(".headline", { type: "words" })
gsap.from(split.words, {
  clipPath: "inset(0 100% 0 0)", opacity: 0,
  stagger: 0.08, duration: 0.7, ease: "expo.out"
})
```

### 27. Number Odometer
```js
const obj = { n: 0 }
gsap.to(obj, { n: 100, duration: 2, ease: "power2.inOut",
  onUpdate: () => el.textContent = obj.n.toFixed(0) + "%" })
```

### 28. Glitch Text
```js
const tl = gsap.timeline({ repeat: -1, repeatDelay: 3 })
tl.to(".glitch", { skewX: 20, duration: 0.1 })
  .to(".glitch", { skewX: 0, duration: 0.1 })
  .to(".glitch", { opacity: 0, duration: 0.05 })
  .to(".glitch", { opacity: 1, duration: 0.05 })
  .to(".glitch", { x: 5, duration: 0.05 })
  .to(".glitch", { x: 0, duration: 0.05 })
```

---

## 🟣 LOOP & AMBIENT

### 29. Infinite Rotation
```js
gsap.to(".spinner", { rotation: 360, duration: 2, repeat: -1, ease: "none" })
```

### 30. Floating Element
```js
gsap.to(".float", { y: -20, duration: 2, repeat: -1, yoyo: true, ease: "sine.inOut" })
```

### 31. Heartbeat Pulse
```js
gsap.to(".pulse", { scale: 1.1, duration: 0.4, repeat: -1, yoyo: true, ease: "power1.inOut" })
```

### 32. News Ticker
```js
gsap.to(".ticker-inner", {
  xPercent: -50, ease: "none", duration: 20, repeat: -1,
  modifiers: { xPercent: gsap.utils.wrap(-50, 0) }
})
```

### 33. Breathing Background
```js
gsap.to("body", {
  backgroundColor: "#1a0a2e",
  duration: 4, repeat: -1, yoyo: true, ease: "sine.inOut"
})
```

---

## ⚪ SVG & SHAPE

### 34. Draw SVG Logo
```js
gsap.from(".logo path", {
  drawSVG: "0%", duration: 2.5, stagger: 0.3, ease: "power2.inOut"
})
```

### 35. Morph Shape
```js
gsap.to("#shape", { morphSVG: "#target-shape", duration: 1.5, ease: "elastic.out(1, 0.5)", repeat: -1, yoyo: true })
```

### 36. Motion Path
```js
gsap.to(".car", {
  motionPath: { path: "#road", align: "#road", autoRotate: true },
  duration: 5, ease: "none", repeat: -1
})
```

### 37. SVG Stroke Dash
```js
const length = path.getTotalLength()
gsap.fromTo(path,
  { strokeDasharray: length, strokeDashoffset: length },
  { strokeDashoffset: 0, duration: 2, ease: "power2.inOut" }
)
```

---

## 🧡 LAYOUT & PAGE

### 38. Flip Layout
```js
const state = Flip.getState(".items")
// [DOM change]
Flip.from(state, { duration: 0.8, ease: "power2.inOut", stagger: 0.05 })
```

### 39. Page Transition Out
```js
gsap.to(".page", { opacity: 0, y: -40, duration: 0.5, ease: "power2.in",
  onComplete: () => window.location.href = url })
```

### 40. Loading Screen
```js
const tl = gsap.timeline({ onComplete: () => gsap.set(".loader", { display: "none" }) })
tl.to(".progress", { scaleX: 1, duration: 1.5, ease: "power2.inOut" })
  .to(".loader", { yPercent: -100, duration: 0.8, ease: "expo.inOut" })
  .from(".content", { opacity: 0, y: 40, duration: 0.8 }, "-=0.3")
```

---

## ⚡ ADVANCED / LEVEL 8-10

### 41. Particle System (Canvas + GSAP)
Use GSAP ticker with canvas to animate hundreds of particles.

### 42. Scroll-linked 3D Scene
Combine Three.js camera movement with ScrollTrigger scrub.

### 43. Custom Cursor
```js
const cursor = document.querySelector(".cursor")
window.addEventListener("mousemove", (e) => {
  gsap.to(cursor, { x: e.clientX, y: e.clientY, duration: 0.1 })
})
```

### 44. Text Reveal on Scroll (Lines)
```js
const lines = new SplitText(".body-text", { type: "lines" })
gsap.from(lines.lines, {
  opacity: 0, y: 20, stagger: 0.08,
  scrollTrigger: { trigger: ".body-text", start: "top 75%", toggleActions: "play none none reverse" }
})
```

### 45. Quick-To (Performance Hover)
```js
const xTo = gsap.quickTo(".el", "x", { duration: 0.3, ease: "power3" })
const yTo = gsap.quickTo(".el", "y", { duration: 0.3, ease: "power3" })
window.addEventListener("mousemove", e => { xTo(e.clientX); yTo(e.clientY) })
```

---

## PLUGIN QUICK REFERENCE

| Plugin | CDN Available Free | Use Case |
|--------|-------------------|----------|
| ScrollTrigger | ✅ | Scroll-driven animations |
| TextPlugin | ✅ | Typewriter effect |
| MotionPathPlugin | ✅ | Animate along SVG path |
| Draggable | ✅ | Drag & drop with physics |
| Flip | ✅ | Animate layout changes |
| CustomEase | ✅ | Bezier curve easing |
| EasePack | ✅ | Extra ease functions |
| SplitText | 🔐 Club | Text splitting for animation |
| MorphSVG | 🔐 Club | SVG shape morphing |
| DrawSVG | 🔐 Club | SVG stroke animation |
| ScrambleText | 🔐 Club | Scramble/decode text |
| Physics2D | 🔐 Club | 2D physics simulation |
| GSDevTools | 🔐 Club | Debug animation timeline |

> 🔐 Club plugins require a GreenSock Club membership. For demos, codepen proxy works.
