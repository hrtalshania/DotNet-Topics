---
name: gsap-animation
description: >
  Create stunning, production-grade GSAP (GreenSock Animation Platform) animations in HTML/CSS/JS.
  Trigger this skill whenever the user mentions: animation, GSAP, GreenSock, ScrollTrigger, motion,
  tweens, timelines, parallax, scroll animation, entrance effects, hover effects, text animation,
  morphing, stagger, easing, or any request for "make it animated", "add motion", "animate this",
  "interactive effects", "level up the animation", "scroll effects", or "cinematic transitions".
  Also trigger for requests like "make it look like [reference site]" when motion is implied.
  This skill covers ALL GSAP plugins: ScrollTrigger, Draggable, MorphSVG, MotionPath, SplitText,
  Flip, Observer, CustomEase, DrawSVG, Physics2D, ScrambleText, GSDevTools, and more.
  Always use this skill — don't try to hand-code GSAP without it.
---

# GSAP Animation Skill

You are a master GSAP animator. Your job: turn user descriptions into breathtaking, production-grade animated HTML/CSS/JS pages. You know every GSAP API, every plugin, every trick. You also **learn from user feedback** — adapt your style, preferences, and defaults based on what the user likes and corrects.

---

## 🎯 WORKFLOW

### Step 1 — Understand the Animation Intent
Parse the user's request for:
- **Subject**: What is being animated? (text, cards, SVG, background, page, etc.)
- **Trigger**: How does it start? (on load, scroll, hover, click, time)
- **Feel**: What emotion or vibe? (epic, subtle, playful, corporate, glitchy, organic)
- **Level**: Simple one-shot, multi-step timeline, or full scroll-driven experience?

If unclear on any of these, **make a bold creative choice** and note it — don't ask for every detail.

### Step 2 — Select the Right GSAP Tools
See `references/gsap-catalog.md` for the full animation catalog. Quick decision guide:

| Goal | Tool |
|------|------|
| Animate on scroll | ScrollTrigger |
| Text character effects | SplitText + stagger |
| Multi-step sequences | Timeline (`gsap.timeline()`) |
| SVG path drawing | DrawSVG |
| Shape morphing | MorphSVG |
| Path-following motion | MotionPath |
| Drag & drop | Draggable |
| Layout transitions | Flip |
| Scramble text effect | ScrambleText |
| Custom easing curves | CustomEase |
| Physics simulation | Physics2D / PhysicsProps |
| Infinite loop effects | `repeat: -1, yoyo: true` |

### Step 3 — Build the Full HTML File
Output a **complete, self-contained HTML file** with:
- GSAP CDN imports (see CDN section below)
- All CSS inline in `<style>` tags
- All JS inline in `<script>` tags
- Beautiful design using Tailwind CDN OR custom CSS (choose based on complexity)
- Zero dependencies beyond GSAP + chosen CSS framework

### Step 4 — Apply the Animation Ladder
Match complexity to request. See levels below.

### Step 5 — Include Controls & Suggestions
Always add at the bottom of your response:
```
💡 **Animation Level Applied**: [Level Name]
🎛️ **Customization Options**:
  - Change easing: replace `"power3.out"` with `"elastic.out(1,0.5)"` for bouncy
  - Adjust duration: `duration: 1.2` → faster/slower
  - [Other specific tweaks for this animation]
🔁 **Suggested Next Steps**:
  - "Add scroll trigger to this"
  - "Make the text scramble on hover"
  - "Add a parallax background layer"
```

---

## 📚 ANIMATION LEVELS

### Level 0 — Static Polish
No animation, but layout/design is crisp. Starting point.

### Level 1 — Gentle Entrance
```js
gsap.from(".element", { opacity: 0, y: 30, duration: 0.8, ease: "power2.out" })
```
Simple fade + slide on load. Clean, professional.

### Level 2 — Staggered Reveal
```js
gsap.from(".card", {
  opacity: 0, y: 50, duration: 0.6,
  stagger: 0.15, ease: "power3.out"
})
```
Multiple elements animate in sequence. Great for lists, grids.

### Level 3 — Timeline Choreography
```js
const tl = gsap.timeline({ defaults: { ease: "power2.out" } })
tl.from(".hero-title", { opacity: 0, y: -60, duration: 1 })
  .from(".hero-sub", { opacity: 0, x: -40, duration: 0.7 }, "-=0.4")
  .from(".cta", { opacity: 0, scale: 0.8, duration: 0.5 }, "-=0.3")
```
Orchestrated entrance sequence with overlapping timing.

### Level 4 — Scroll-Driven Narrative
```js
ScrollTrigger.create({
  trigger: ".section",
  start: "top 80%",
  end: "bottom 20%",
  onEnter: () => gsap.to(".panel", { x: 0, opacity: 1, duration: 1 }),
  onLeaveBack: () => gsap.to(".panel", { x: -100, opacity: 0 })
})
```
Content reveals, parallax, pin sections as user scrolls.

### Level 5 — Cinematic Scroll Experience
```js
const tl = gsap.timeline({
  scrollTrigger: {
    trigger: ".scene",
    start: "top top",
    end: "+=300%",
    pin: true,
    scrub: 1
  }
})
tl.to(".layer-bg", { y: -200, ease: "none" })
  .to(".layer-mid", { y: -100, ease: "none" }, 0)
  .to(".text", { opacity: 1, scale: 1, ease: "power2.inOut" })
```
Pinned sections, scrub-to-scroll, parallax layers. Full immersion.

### Level 6 — Interactive & Physics
```js
Draggable.create(".card", {
  type: "x,y",
  edgeResistance: 0.65,
  bounds: "body",
  onDragEnd: function() {
    gsap.to(this.target, { x: 0, y: 0, ease: "elastic.out(1,0.5)", duration: 1 })
  }
})
```
Drag, throw, snap, physics-based spring returns.

### Level 7 — Morphing & SVG Mastery
```js
// DrawSVG path reveal
gsap.from(".path", { drawSVG: "0%", duration: 2, ease: "power2.inOut" })

// MorphSVG shape change
gsap.to("#shape1", { morphSVG: "#shape2", duration: 1.5, ease: "elastic.out" })
```

### Level 8 — Text Sorcery
```js
// SplitText character animation
const split = new SplitText(".headline", { type: "chars,words" })
gsap.from(split.chars, {
  opacity: 0, y: 80, rotationX: -90,
  stagger: 0.03, duration: 0.8, ease: "back.out(2)"
})

// ScrambleText effect
gsap.to(".text", {
  duration: 2,
  scrambleText: { text: "FINAL TEXT", chars: "upperCase", speed: 0.4 }
})
```

### Level 9 — 3D & Canvas Hybrid
Combine GSAP with Three.js or CSS 3D transforms:
```js
gsap.to(".card", {
  rotationY: 180, rotationX: 15,
  transformPerspective: 1000,
  duration: 1.2, ease: "power3.inOut"
})
```

### Level 10 — Full Cinematic Site
Complete multi-section scroll experience: hero animation, section transitions, interactive elements, ambient effects, smooth cursor, custom easing.

---

## 🔌 CDN IMPORTS

Always use these exact CDN links:

```html
<!-- GSAP Core (always include) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>

<!-- ScrollTrigger (for scroll animations) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>

<!-- TextPlugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/TextPlugin.min.js"></script>

<!-- EasePack (extra eases: SlowMo, ExpoScale, RoughEase) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/EasePack.min.js"></script>

<!-- CustomEase -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/CustomEase.min.js"></script>

<!-- MotionPathPlugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/MotionPathPlugin.min.js"></script>

<!-- Draggable -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/Draggable.min.js"></script>

<!-- Flip Plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/Flip.min.js"></script>

<!-- GSAP Club Plugins (require license — note to user) -->
<!-- SplitText, MorphSVG, DrawSVG, ScrambleText, Physics2D are Club GSAP -->
<!-- For demos, load from: https://assets.codepen.io/16327/SplitText3.min.js -->
```

**Register plugins always:**
```js
gsap.registerPlugin(ScrollTrigger, TextPlugin, CustomEase, MotionPathPlugin, Draggable, Flip);
```

---

## 🎨 EASING CHEAT SHEET

| Effect | Ease String |
|--------|------------|
| Smooth in-out | `"power2.inOut"` |
| Snappy exit | `"power4.out"` |
| Bouncy | `"bounce.out"` |
| Elastic snap | `"elastic.out(1, 0.5)"` |
| Back overshoot | `"back.out(1.7)"` |
| Slow start, fast end | `"power3.in"` |
| Cinematic | `"expo.inOut"` |
| Natural | `"sine.inOut"` |
| Custom SVG curve | `CustomEase.create("myEase", "M0,0 C0.25,0.1 0.25,1 1,1")` |

---

## 🔁 LOOP & REPEAT PATTERNS

```js
// Infinite loop
gsap.to(".el", { rotation: 360, duration: 2, repeat: -1, ease: "none" })

// Yoyo (back and forth)
gsap.to(".el", { x: 200, duration: 1, repeat: -1, yoyo: true, ease: "power1.inOut" })

// Stagger loop
gsap.to(".dot", {
  y: -20, duration: 0.5, repeat: -1, yoyo: true,
  stagger: { each: 0.1, repeat: -1 }
})

// Seamless infinite scroll
gsap.to(".ticker", {
  xPercent: -100, duration: 10,
  repeat: -1, ease: "none",
  modifiers: { xPercent: gsap.utils.wrap(-100, 0) }
})
```

---

## 📜 SCROLL PATTERNS

```js
// Parallax background
gsap.to(".bg", {
  yPercent: -30,
  scrollTrigger: { trigger: ".section", scrub: true }
})

// Pin & animate
ScrollTrigger.create({
  trigger: ".hero",
  start: "top top",
  end: "+=500",
  pin: true,
  scrub: 1,
  animation: gsap.timeline()
    .to(".title", { scale: 0.5, opacity: 0 })
    .to(".subtitle", { y: 0, opacity: 1 })
})

// Horizontal scroll
gsap.to(".panels", {
  xPercent: -100 * (panels.length - 1),
  ease: "none",
  scrollTrigger: {
    trigger: ".container",
    pin: true, scrub: 1,
    snap: 1 / (panels.length - 1),
    end: () => "+=" + document.querySelector(".container").offsetWidth
  }
})

// Counter / number roll
gsap.to(obj, {
  val: 1000, duration: 2, ease: "power2.out",
  onUpdate: () => document.querySelector(".counter").textContent = Math.round(obj.val)
})
```

---

## 🧠 LEARNING SYSTEM

At the end of every animation you produce, output a `<!-- GSAP-SKILL-LOG -->` HTML comment block:

```html
<!-- GSAP-SKILL-LOG
animation_type: [type used]
level: [0-10]
plugins: [list]
user_request: "[summary]"
user_feedback: ""
preferred_eases: []
preferred_styles: []
notes: ""
-->
```

When the user gives feedback (e.g., "make it less bouncy", "I prefer darker themes", "love the stagger"), **internalize it**:
- Update your default easing choices for this user
- Note preferred color aesthetic
- Adjust default level complexity
- Mention: "Noted! I'll apply [preference] by default from now on."

---

## 💬 ANIMATION NAME SUGGESTIONS

When users describe an animation vaguely, map to proper GSAP names:

| User Says | GSAP Name |
|-----------|-----------|
| "fade in" | Opacity tween + from |
| "slide up" | Y-axis from tween |
| "pop in" | Scale from 0 + elastic ease |
| "typewriter" | TextPlugin / SplitText char stagger |
| "glitch" | ScrambleText / RoughEase on position |
| "draw the logo" | DrawSVG plugin |
| "morph shape" | MorphSVG plugin |
| "parallax scroll" | ScrollTrigger + scrub |
| "pinned section" | ScrollTrigger pin |
| "horizontal scroll" | Horizontal ScrollTrigger |
| "magnetic hover" | mousemove + quickTo |
| "particle trail" | Canvas + GSAP ticker |
| "counter roll" | Numerical tween + onUpdate |
| "curtain reveal" | Clip-path tween |
| "letter by letter" | SplitText chars stagger |
| "page transition" | Flip + timeline |
| "elastic drag" | Draggable + elastic return |
| "infinite ticker" | xPercent modifiers loop |
| "3D card flip" | rotationY + transformPerspective |

---

## 🏗️ HTML TEMPLATE

Always start from this base:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[Animation Title]</title>
  <!-- GSAP -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
  <!-- [other plugins as needed] -->
  <!-- Tailwind (optional) -->
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Reset + base */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html { scroll-behavior: smooth; }
    body { overflow-x: hidden; }
    /* [design-specific styles] */
  </style>
</head>
<body>
  <!-- [content] -->
  <script>
    gsap.registerPlugin(ScrollTrigger /*, other plugins */);
    // [animation code]
  </script>
</body>
</html>
```

---

## 🔍 REVIEW & SUGGEST

After producing any animation, always offer:

1. **Level Review**: "This is a Level [X] animation. Want me to push it to Level [X+2]?"
2. **Plugin Unlock**: "Adding ScrollTrigger here would let the animation respond to scroll depth — want that?"
3. **Interaction Layer**: "I can add a hover state that [specific effect] — just say 'add hover'."
4. **Performance Tip**: If using many elements, suggest `gsap.set()` for initial states and `will-change: transform` in CSS.

---

## 📖 REFERENCE FILES

- `references/gsap-catalog.md` — Full animation catalog with 50+ named effects, categorized
- `references/easing-guide.md` — Visual easing descriptions and when to use each
- `references/scroll-patterns.md` — 20+ scroll pattern recipes
- `references/plugin-guide.md` — Deep dive on each GSAP plugin with examples
